# Home - SMART DAK SRV v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/dak-srv/ImplementationGuide/smart.who.int.dak-srv | *Version*:1.0.0 |
| Active as of 2026-03-18 | *Computable Name*:DAKSRV |

### Summary

The WHO Health Emergencies Programme (WHE) supports countries in building resilient and responsive surveillance systems to detect, monitor, and respond to public health threats. A cornerstone of this work is strengthening the quality, interoperability, and use of surveillance data for early detection, situational awareness, and timely response. To support this, WHO developed a Digital Adaptation Kit (DAK) for surveillance. This DAK translates WHO surveillance guidelines into a structured format to support implementation in digital systems. It provides standardized content for workflows, data elements, decision-support logic, and indicators, enabling better alignment of national systems with global standards.

### L1 Narrative guidelines

This first volume of the Surveillance DAK includes both disease-agnostic components and disease-specific modules for conditions like cholera, measles, meningitis, and yellow fever. This modular approach allows countries to adapt and scale the DAK content based on their national priorities, surveillance capacities, and digital maturity.

The development of the Surveillance DAK was informed by key WHO guidance documents on surveillance, including the WHO Global Strategy for Collaborative Surveillance, the Integrated Disease Surveillance and Response (IDSR) guidelines, and various disease-specific surveillance standards (e.g. for cholera, measles, meningitis, yellow fever, etc.). These documents outline surveillance objectives, case definitions, data flows, reporting requirements, and recommended indicators. They were reviewed and synthesized to inform the digital content of the Surveillance DAK. In addition, WHO technical teams and country stakeholders contributed to the prioritization and validation of content. Links to the primary guidance documents used to develop this DAK can be found in Table 3 of the DAK.

### L2 Operational guidelines

The DAK for Surveillance and the associated implementations tools can be found here:

* [Published DAK Document](https://iris.who.int/handle/10665/385079)

* Implementation tools:

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the Surveillance SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the Surveillance SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the Surveillance SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

For more license details please see the [license page](https://smart.who.int/dak-srv/license.html).

### Providing Feedback

Feedback specific to this specification can provided through:

Clicking on one of the **Feedback** links to the right of any section header

Sending an email to [SMART@who.int](mailto:SMART@who.int)

Creating an issue on the GitHub [dak-srv repository](https://github.com/WorldHealthOrganization/smart-dak-srv)

