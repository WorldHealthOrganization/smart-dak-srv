# User Scenarios - SMART DAK SRV v0.9.9

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **User Scenarios**

## User Scenarios

Component 3 in the Digital Adaptation Kit includes user scenarios, which are narratives that describe how the different personas may interact with each other and with the digital system. The user scenario is provided to help the reader better understand how the system will be used and how it would fit into existing workflows.

Please consult chapter 3 from the SRV DAK where all scenarios are presented.

**How to interpret user scenarios**

User scenarios can be helpful tools not only to better understand the context in which a digital tool would operate, but also for some insights into what key data elements would need to be recorded and accounted for in the database. Additionally, the context in which the tool would operate, illuminated by the user scenarios, provides insight into some functional and non-functional requirements that the system would also need.

As examples, the scenarios identify:

* key data elements that need to be recorded and/or calculated;
* decision-support logic that can be automated in the system;
* key functional and non-functional requirements that should be included in the system.

