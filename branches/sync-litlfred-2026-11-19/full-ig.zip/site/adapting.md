# Adapting Guidelines for Country use - SMART DAK SRV v1.0.1

* [**Table of Contents**](toc.md)
* [**Home**](index.md)
* **Adapting Guidelines for Country use**

## Adapting Guidelines for Country use

The following page provides a reference to resources that can guide countries in adapting the guidelines for country use.

The digital adaptation kit included in this implementation guide provides the generic, software agnostic and software neutral content requirements. They are documentation of generic system requirements that need to then be adapted to local needs; and subsequently used to inform the design of digital systems implemented locally.

WHO guidelines articulate and endorse rigorously tested recommendations for health interventions to be adopted within country programs. When applied correctly and consistently, guideline recommendations save lives. To ensure that countries can effectively benefit from digital health investments, the SMART Guidelines approach is intended to facilitate the adoption of WHO’s clinical, public health and data use guidelines in an accurate way in the digital systems that countries are adopting. For more on layers of knowledge representation and how they are used in WHO’s SMART Guidelines approach, see [WHO’s SMART Guidelines](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) and this [Lancet article](https://www.thelancet.com/journals/landig/article/PIIS2589-7500(21)00038-8/fulltext).

